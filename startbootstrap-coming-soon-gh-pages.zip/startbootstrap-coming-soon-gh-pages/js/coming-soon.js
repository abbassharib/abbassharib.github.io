(function($) {
  "use strict"; // Start of use strict

  // No JS

})(jQuery); // End of use strict
